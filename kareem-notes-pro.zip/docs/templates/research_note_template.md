---
title: "<topic / paper name>"
tags: [research, <area>]
tldr: "<1-2 lines>"
---

## Problem
<>

## Approach (algorithms / models)
<>

## Results
<>

## Critique / Next steps
<>
