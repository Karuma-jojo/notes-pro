---
title: "<theorem name>"
tags: [math, <area>, theorem]
tldr: "<one-sentence statement>"
---

## Statement
<formal statement>

## Intuition
<why it's true / pictures in words>

## Proof (sketch)
<outline>

## Common uses
- <>
