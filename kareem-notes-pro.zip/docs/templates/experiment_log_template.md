---
title: "Experiment: <name>"
tags: [experiment, <area>]
tldr: "<goal + metric>"
---

## Setup
- Data:
- Model:
- Hardware:
- Seed(s):

## Procedure
- <steps>

## Results
- Metrics:
- Observations:

## Next
- <iterate>
