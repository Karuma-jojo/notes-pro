---
title: "<challenge> — <box/site>"
tags: [ctf, <category>, <platform>, <phase>]
platform: <linux|windows|cloud|docker|kubernetes>
phase: <recon|enum|exploit|privesc|post-ex>
difficulty: <easy|medium|hard>
tldr: "<one-line takeaway>"
refs:
  - <urls>
---

## TL;DR
<2-3 bullets or a short paragraph>

## Enumeration
```bash
# commands
```

## Exploitation
```bash
# payloads
```

## Privilege Escalation
```bash
# privesc steps
```

## Post-Exfil & Notes
- <loot>
- <persistence / cleanup>
