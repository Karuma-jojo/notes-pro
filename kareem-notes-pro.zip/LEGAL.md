# Legal & Ethics

- Use techniques **only on systems you own or have explicit permission to test**.
- Remove sensitive tokens, secrets, and personal data from your notes before publishing.
- Attribute sources (CTFs, authors, CVEs) where applicable.
