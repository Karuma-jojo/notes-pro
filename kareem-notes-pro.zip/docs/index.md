---
title: Home
tags: [home, index]
tldr: Landing page with pointers and quick search.
---

# Kareem's Knowledge Base

Search (top right) for commands, concepts, and write-ups.

**Inbox first**: drop raw notes in `docs/inbox/` and tag later.

> Tip: Use global search + the **Tags** page to filter by domain (ctf, math, ai, kaggle, swe) and tactic (privesc, enum, rce...).

